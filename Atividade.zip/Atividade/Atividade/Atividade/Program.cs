﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading;



class program
{
    // Lock para sincronizar o acesso ao console
    static object lockConsole = new object();

    // Banco de dados de funcionários
    static string[] nomes = {
            "Ana", "Carlos", "Mariana", "João", "Fernanda",
            "Pedro", "Lucas", "Juliana", "Rafael", "Beatriz"
        };

    // Banco de dados de salários
    static 
        double[] salarios = {
            3000, 4500, 5000, 2800, 5200,
            4100, 3900, 4700, 6000, 3500
        };

    // Banco de dados de cargos
    static string[] cargos = {
        "Gerente", "Analista", "Desenvolvedor", "Suporte", "RH",
        "Financeiro", "Tester", "Designer", "DevOps", "Diretor"
    };



    static void mostraFuncionario(int inicio, int fim)
    {
        for(int i = inicio; i < fim; i++)
        {
            // Sincroniza o acesso ao console para evitar que as informações se misturem
            lock (lockConsole) { 
                Console.WriteLine($"Nome: {nomes[i]}");
            Console.WriteLine($"Salário: R$ {salarios[i]:F2}");
            Console.WriteLine($"Cargo: {cargos[i]}");
            Console.WriteLine("--------------------");
            }
            Thread.Sleep(500);
        }
    }



    static void somaSalarios()
    {
        double total = 0;
        for(int i = 0; i < salarios.Length; i++)
        {
            total += salarios[i];
        }
        Console.WriteLine("Soma dos Salários: R$ " + total.ToString("F2"));
    }

    // Método para calcular e mostrar o resumo financeiro
    static void resumoFinanceiro()
    {
        double total = 0;
        double maior = salarios[0];
        double menor = salarios[0];

        for (int i = 0; i < salarios.Length; i++)
        {
            total += salarios[i];

            if (salarios[i] > maior)
                maior = salarios[i];

            if (salarios[i] < menor)
                menor = salarios[i];
        }

        double media = total / salarios.Length;

        lock (lockConsole)
        {
            Console.WriteLine("\n--- RESUMO FINANCEIRO ---");

            Console.WriteLine($"Total de funcionários: {salarios.Length}");
            Console.WriteLine($"Total salarial: R$ {total:F2}");
            Console.WriteLine($"Média salarial: R$ {media:F2}");
            Console.WriteLine($"Maior salário: R$ {maior:F2}");
            Console.WriteLine($"Menor salário: R$ {menor:F2}");

            Console.WriteLine("--------------------------\n");
            Thread.Sleep(1000);
        }
    }

    static void Main()
    {
        // Inicia o contador de tempo
        var sw = new Stopwatch();
        sw.Start();

        // Divide o array de funcionários em duas partes para as threads
        int meio = nomes.Length / 2;

        // Inicia as threads para mostrar os funcionários
        Console.WriteLine("BANCO DE DADOS DE FUNCIONÁRIOS DA EMPRESA\n");
        Console.WriteLine("Gerando Funcionários...\n");
        Thread.Sleep(1000);

        Console.WriteLine("Funcionários:\n");
        Thread t1 = new Thread(() => mostraFuncionario(0, meio));
        t1.Start();
        Thread t2 = new Thread(() => mostraFuncionario(meio, nomes.Length));
        t2.Start();
        Thread t3 = new Thread(resumoFinanceiro);

        // Aguarda as threads encerrarem para continuar
        t1.Join();
        t2.Join();


        Console.WriteLine("\nTodos os funcionários foram gerados!\n");
        Thread.Sleep(1000);

        // Inicia a thread para calcular o resumo financeiro
        t3.Start();

        // Aguarda a thread do resumo financeiro encerrar
        t3.Join();

        //Encerrando o contador de tempo
        sw.Stop();

        Console.WriteLine($"Tempo decorrido: {sw.Elapsed.TotalSeconds:F2} s"); 
        Console.WriteLine("Programa encerrado!");
    }

}