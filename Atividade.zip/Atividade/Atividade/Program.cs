﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading;



class program
{
    static string[] nomes = {
            "Ana", "Carlos", "Mariana", "João", "Fernanda",
            "Pedro", "Lucas", "Juliana", "Rafael", "Beatriz"
        };

    // Banco de dados de salários
    static 
        double[] salarios = {
            3000, 4500, 5000, 2800, 5200,
            4100, 3900, 4700, 6000, 3500
        };
    static string[] cargos = {
        "Gerente", "Analista", "Desenvolvedor", "Suporte", "RH",
        "Financeiro", "Tester", "Designer", "DevOps", "Diretor"
    };



    static void mostraNomes()
    {
        foreach (string nome in nomes)
        {
            Console.WriteLine(nome);
            Thread.Sleep(1000);
        }
    }

    static void mostraSalario()
    {
        foreach (double salario in salarios)
        {
            {
                Console.WriteLine(salario);
                Thread.Sleep(1000);
            }

        }
    }

    static void mostraCargos()
    {
        foreach (string cargo in cargos)
        {
            {
                Console.WriteLine(cargo);
                Console.WriteLine();
                Thread.Sleep(1000);
            }

        }
    }


    static void Main()
    {
        // Inicia o contador de tempo
        var sw = new Stopwatch();
        sw.Start();

        // Roda o método estático ContaImpares()
        Thread t1 = new Thread(new ThreadStart(mostraNomes));
        t1.Start(); // Inicia a thread     

        // Roda o método estático ContaPares()
        Thread t2 = new Thread(new ThreadStart(mostraSalario));
        t2.Start(); // Inicia a thread     

        Thread t3 = new Thread(new ThreadStart(mostraCargos));
        t3.Start(); // Inicia a thread   

        // Aguarda as threads encerrarem para continuar
        t1.Join();
        t2.Join();
        t3.Join();

        sw.Stop();
        Console.WriteLine($"Tempo decorrido: {sw.Elapsed.TotalMilliseconds/1000} s");

        Console.WriteLine("Programa encerrado!");
    }

}