﻿using System;
using System.Diagnostics;
using System.Threading;

/* 
 * Conta número impares e pares de rotinas diferentes.
 * Cada rotina roda em um thread diferente.
 * É aberto um processo para cada rotina no SO!
 */

class Program
{

    static void ContaImpares()
    {
        for (int i = 1; i <= 40; i += 2)
        {
            Console.WriteLine(i);
            Thread.Sleep(500);
        }
    }

    static void ContaPares()

    {
        for (int i = 2; i <= 40; i += 2)
        {
            Console.WriteLine(i);
            Thread.Sleep(500);
        }
    }

    static void Main()
    {
        // Inicia o contador de tempo
        var sw = new Stopwatch();
        sw.Start();

        // Roda o método estático ContaImpares()
        Thread t1 = new Thread(new ThreadStart(ContaImpares));
        t1.Start(); // Inicia a thread     

        // Roda o método estático ContaPares()
        Thread t2 = new Thread(new ThreadStart(ContaPares));
        t2.Start(); // Inicia a thread     

        // Aguarda as threads encerrarem para continuar
        t1.Join();
        t2.Join();

        sw.Stop();
        Console.WriteLine($"Tempo decorrido: {sw.Elapsed.TotalMilliseconds/1000} s");

        Console.WriteLine("Programa encerrado!");
    }
}