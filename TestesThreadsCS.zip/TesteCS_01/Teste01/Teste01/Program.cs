﻿using System;
using System.Diagnostics;

/* 
 * Conta número impares e DEPOIS conta números pares
 */

class Program
{

    static void ContaImpares()
    {
        for (int i = 1; i <= 40; i += 2)
        {
            Console.WriteLine(i);
            Thread.Sleep(500);
        }
    }

    static void ContaPares()

    {
        for (int i = 2; i <= 40; i += 2)
        {
            Console.WriteLine(i);
            Thread.Sleep(500);
        }
    }

    static void Main()
    {
        // Inicia o contador de tempo
        var sw = new Stopwatch();
        sw.Start();

        ContaImpares();
        ContaPares();

        sw.Stop();
        Console.WriteLine($"Tempo decorrido: {sw.Elapsed.TotalMilliseconds / 1000} s");

        Console.WriteLine("Programa encerrado!");
    }
}