﻿using System;
using System.Diagnostics;
using System.Threading;

/* 
 * Conta número impares e pares utilizando a mesma rotina em threads diferentes.
 * Cada rotina roda em uma thread diferente.
 * É aberto um processo para cada execução da rotina no SO!
 */

class Program
{

    static void Conta2em2(object param)
    {
        int inicio = (int)param;

        for (int i = inicio; i <= 40; i += 2)
        {
            Console.WriteLine(i);
            Thread.Sleep(500);
        }
    }

    static void Main()
    {
        // Inicia o contador de tempo
        var sw = new Stopwatch();
        sw.Start();

        // Roda o método estático ContaImpares()
        Thread t1 = new Thread(new ParameterizedThreadStart(Conta2em2));
        t1.Start(1); // Inicia a thread passando o parâmetro 1 como início

        // Roda o método estático ContaPares()
        Thread t2 = new Thread(new ParameterizedThreadStart(Conta2em2));
        t2.Start(2); // Inicia a thread passando o parâmetro 2 como início

        // Aguarda as threads encerrarem para continuar
        t1.Join();
        t2.Join();

        sw.Stop();
        Console.WriteLine($"Tempo decorrido: {sw.Elapsed.TotalMilliseconds / 1000} s");

        Console.WriteLine("Programa encerrado!");
    }
}
